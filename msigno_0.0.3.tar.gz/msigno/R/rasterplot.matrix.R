#' Black-white plot to visualize a matrix
#'
#' @export
#' @author Mirko Signorelli
#' @examples
#' x = matrix(runif(25), 5, 5)
#' rasterplot.matrix(x, title = 'Hello')
 
rasterplot.matrix = function(x, xlab = NULL, ylab = NULL, title = NULL) {
  if (!is.matrix(x)) stop('x should be a matrix')
  require(raster)
  image(x, col=grey(seq(0, 1, length = 256)), axes = F, main = title)
  xval = seq(0, 1, length = nrow(x))
  yval = seq(0, 1, length = ncol(x))
  if (is.null(xlab)) xlab = 1:nrow(x)
  if (is.null(xlab)) ylab = 1:ncol(x)
  axis(1, at = xval, labels = xlab)
  axis(2, at = xval, labels = ylab)
}
