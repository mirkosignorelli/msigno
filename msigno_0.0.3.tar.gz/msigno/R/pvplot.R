#' Plot comparing observed log10(pvalues) with expected values under the null hypothesis
#'
#' @export
#' @author Mirko Signorelli
#' @examples
#' set.seed(1)
#' x = c(runif(50), 1e-5, 1e-4)
#' pvplot(x, x.inset = -0.3)
 
pvplot = function(x, xlim = NULL, main = NULL, 
                  pch = 15, alpha = 0.05, x.inset = -0.5) {
  x = x[order(x)]
  q = length(x)
  p.exp = (1:q-0.5)/q
  df.pp = data.frame('mlp' = -log(x, base = 10),
                     'mlp.null' = -log(p.exp, base = 10))
  fdr = p.adjust(x, method = 'BH')
  col = ifelse(fdr < alpha, 'blue', 'black')
  if (is.null(xlim)) xlim = c(0, range(df.pp$mlp)[2])
  par(xpd = T, mar = c(5.1, 4.5, 4.1, 9))
  plot(df.pp$mlp.null, df.pp$mlp, xlim = xlim, ylim = xlim,
       main = main, pch = pch, col = col, xlab = expression('Expected -log'[10]*'p'),
       ylab = expression('-log'[10]*'p'), cex.lab = 1.5, bty = 'l')
  legend(x = "right", inset=c(x.inset,0), paste(c('FDR <', 'FDR >'), alpha), pch = 16,
         col = c('blue', 'black'), bty = 'n', cex = 1.1)
  par(xpd = F)
  abline(a = 0, b= 1, col = 'red', lwd = 2)
}
