#' Shortcut to clean the environment while retaining certain objects
#'
#' @export
#' @author Mirko Signorelli
#' @examples
#' x = 2
#' y = 5
#' z = 73
#' rm.but(c('x', 'z'))

rm.but = function(x = 'hi') {
  suppressMessages(require(gdata))
  keep(list = as.list(x), sure = T)
}
