#' Shortcut for main diagonal in plot
#'
#' @export
#' @author Mirko Signorelli
#' @examples
#' x = rnorm(50)
#' y = rnorm(50)
#' plot(x, y)
#' yx()

yx = function(col = 'red', lty = 2, lwd = 2) {
  abline(a = 0, b = 1, col = col, lty = lty, lwd = lwd)
}
