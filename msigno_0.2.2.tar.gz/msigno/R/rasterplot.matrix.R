#' Black-white plot to visualize a matrix
#'
#' @export
#' @author Mirko Signorelli
#' @examples
#' x = matrix(runif(25), 5, 5)
#' rasterplot.matrix(x, title = 'Hello')
 
rasterplot.matrix = function(x, xval = NULL, xlab = 'x', 
                             yval = NULL, ylab = 'y', title = NULL) {
  if (!is.matrix(x)) stop('x should be a matrix')
  require(raster)
  image(x, col=grey(seq(0, 1, length = 256)), axes = F, 
        main = title, xlab = xlab, ylab = ylab)
  xpos = seq(0, 1, length = nrow(x))
  ypos = seq(0, 1, length = ncol(x))
  if (is.null(xval)) xval = 1:nrow(x)
  if (is.null(yval)) yval = 1:ncol(x)
  axis(1, at = xpos, labels = xval)
  axis(2, at = ypos, labels = yval)
}
