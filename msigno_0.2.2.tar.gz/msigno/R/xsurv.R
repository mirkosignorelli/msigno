#' Visualize association between survival time and a covariate of interest
#'
#' @param x a covariate of interest
#' @param t the survival time
#' @param delta dummy variable: 1 if t is observed, 0 if it is right-censored
#' @param panels single plot: 1, two plots with split by delta: 2 (default)
#' @param ... additional graphic parameters (xlab, ylab, cols, x.inset...)
#' @export
#' @author Mirko Signorelli
#' @examples
#' library(survival)
#' xsurv(x = lung$meal.cal, t = lung$time, delta = ifelse(lung$status == 2, 1, 0))
#' xsurv(x = lung$ph.karno, t = lung$time, delta = ifelse(lung$status == 2, 1, 0))      

xsurv = function(x, t, delta, panels = 2, xlab = 'x', ylab = 'y',
                 cols = c('blue', 'orange'), x.inset = -0.25) {
  id.cens = which(delta == 0)
  id.obs = which(delta == 1)
  par(bty = 'l')
  if (panels == 1) {
    par(mar = c(4, 4, 2, 7))
    col = ifelse(delta == 1, cols[1], cols[2])
    pch = ifelse(delta == 1, 15, 16)
    plot(x, t, col = col, pch = pch, xlab = xlab, ylab = ylab)
    legend(x = 'right', xpd = T, inset = x.inset, bty = 'n',
           col = cols, pch = c(15, 16),
           legend = c('observed', 'censored'))
  }
  if (panels == 2) {
    par(mfrow = c(1, 2))
    title.obs = 'Event observed'
    title.cens = 'Event censored'
    sub.obs = sub.cens = ''
    if (length(id.cens) >= 5) {
      cor.cens = cor(x[id.cens], t[id.cens], use = "complete.obs")
      sub.cens = paste('correlation =', round(cor.cens, 3))
    }
    if (length(id.obs) >= 5) {
      cor.obs = cor(x[id.obs], t[id.obs], use = "complete.obs")
      sub.obs = paste('correlation =', round(cor.obs, 3))
    }
    plot(x[id.obs], t[id.obs], pch = 16,
         xlab = xlab, ylab = ylab, col = cols[1],
         main = title.obs, sub = sub.obs)
    plot(x[id.cens], t[id.cens], pch = 16,
         xlab = xlab, ylab = ylab, col = cols[2],
         main = title.cens, sub = sub.cens)
  }
}
