#' Computes the overlap between each pair of vectors gathered in a list
#'
#' @export
#' @author Mirko Signorelli
#' @examples
#' x1 = letters[1:7]
#' x2 = letters[5:10]
#' x3 = c(letters[1], letters[9:20])
#' x = list(x1 = x1, x2 = x2, x3 = x3)
#' list.overlap(x)
 
list.overlap = function(list) {
  sapply(list, function(x) sapply(list, function(y) sum(y %in% x)))
}
