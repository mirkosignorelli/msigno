#' Set folder to script location (in RStudio)
#'
#' This function only works in RStudio; use set.cf() at the beginning of
#' your (saved!) script to set the working directory in the same folder 
#' of the script
#'
#' @export
#' @author Mirko Signorelli
#' @examples
#' \dontrun{
#' set.cf()
#' }

set.cf = function(x) {
  current.folder = dirname(rstudioapi::getActiveDocumentContext()$path)
  setwd(current.folder)
}