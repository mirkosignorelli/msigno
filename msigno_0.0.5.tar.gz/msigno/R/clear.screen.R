#' Clears the console
#'
#' @export
#' @author Mirko Signorelli
#' @examples
#' print(letters)
#' clear.screen()

clear.screen = function(x) cat("\014")
