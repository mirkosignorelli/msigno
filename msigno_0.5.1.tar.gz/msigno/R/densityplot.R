#' Density plot for a continuous random variable
#'
#' This function produces a plot of the kernel estimator
#' of the density of a continuous random variable
#' 
#' @param x the (continuous) variable of interest
#' @param ktype the type of smoothing kernel to be used (see
#' \code{\link{density}})
#' @param kband a smoothing bandwidth method (see \code{\link{bw.nrd}})
#' @param npoints he number of equally spaced points at which the 
#' density is to be estimated (see \code{\link{density}})
#' @param na.rm logical
#' @param xlim limits for the x axis
#' @param title plot title
#' @param xlab label for the x axis
#' @param ylab label for the y axis
#' @param col color used for the area under the density
#' @param col.line color used for the line
#' @param lwd line width
#' @param bty box type (default is \code{bty="l"})
#' @param cex.title title font size
#' @param cex.axis font size for the axes
#' @import graphics
#' @export
#' @author Mirko Signorelli
#' @examples
#' densityplot(cars$dist)

densityplot = function(x, ktype = 'gaussian', kband = 'SJ', 
                       npoints = 512, na.rm = T, xlim = NULL,
                       title = '', xlab = 'x', ylab = 'Density',
                       col = 'lightblue', col.line = 'black', lwd = 1, 
                       bty = 'l', cex.title = NULL, cex.axis = NULL) {
  if (!is.numeric(x)) stop('x is not numeric')
  kern.est = density(x = x, bw = kband, kernel = ktype,
                     n = npoints, na.rm = T)
  if (is.null(xlim)) xlim = c(min(kern.est$x), max(kern.est$x))
  plot(kern.est, xlim = xlim, 
       bty = bty, col = col.line, lwd = lwd,
       cex.axis = cex.axis, cex.lab = cex.axis, cex.main = cex.title,
       xlab = xlab, ylab = ylab, main = title)
  polygon(kern.est, col = col)
}
