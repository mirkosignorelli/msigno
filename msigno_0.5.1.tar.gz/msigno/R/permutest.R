#' Permutation test for differences in the expected value
#' of two groups
#'
#' This function computes a permutation test for the null
#' hypothesis that the expected value of a (discrete) random
#' variable is the same in two groups
#' 
#' @param values a numeric vector with the support of the random variable
#' @param freqA a numeric vector with the frequency of the values in the first group
#' @param freqB a numeric vector with the frequency of the values in the second group
#' @param groups a character vector giving the names of the two groups
#' @param nperm number of permutations to compute
#' @param seed the random seed to initiate the randomizations
#' @export
#' @author Mirko Signorelli
#' @examples
#' values = 1:5
#' freq1 = c(0, 1, 0, 1, 7)
#' freq2 = c(0, 1, 1, 3, 11)
#' freq3 = c(36, 23, 31, 139, 437)
#' permutest(values, freq1, freq2, groups = c('product 1', 'product 2'), 1000)
#' permutest(values, freq1, freq3, groups = c('product 1', 'product 3'), 1000)
#' permutest(values, freq2, freq3, groups = c('product 2', 'product 3'), 1000)

permutest = function(values, freqA, freqB, groups = c('A', 'B'), 
                    nperm = 500, seed = 19920207) {
  set.seed(seed)
  x1 = rep(values, times = freqA)
  df = data.frame(group = groups[1], x = x1)
  x2 = rep(values, times = freqB)
  df = rbind(df, data.frame(group = groups[2], x = x2))
  obs_means = aggregate(x ~ group, data = df, FUN = mean)
  grp_size = aggregate(x ~ group, data = df, FUN = length)
  obs_means$n = grp_size$x
  obs_diff = as.numeric(subset(obs_means, group == groups[1], 'x') -
                          subset(obs_means, group == groups[2], 'x'))
  permutations = replicate(nperm, permuter(df, groups))
  pright = (1 + sum(permutations > obs_diff)) / (nperm + 1)
  pleft = (1 + sum(permutations < obs_diff)) / (nperm + 1)
  ptwosided = 2*min(pleft, pright)
  pvalues = data.frame(
    test = c(paste(groups[1], c('>', '<', '='), groups[2])),
    pvalue = c(pright, pleft, ptwosided) )
  pvalues$pvalue = round(pvalues$pvalue, 4)
  out = list('test' = pvalues, 'obs_means' = obs_means)
  return(out)
}

permuter = function(dataset, groups) {
  new_df = dataset
  new_df$group = sample(dataset$group)
  sample_means = aggregate(x ~ group, data = new_df, FUN = mean)
  out = subset(sample_means, group == groups[1], 'x') -
    subset(sample_means, group == groups[2], 'x')
  as.numeric(out)
}