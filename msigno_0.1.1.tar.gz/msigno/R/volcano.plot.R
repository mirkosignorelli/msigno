#' Creates a volcano plot
#'
#' @export
#' @author Mirko Signorelli
#' @examples
#' set.seed(1)
#' x = c(rnorm(50, sd = 0.3), rnorm(10, sd = 1))
#' p = c(runif(50), runif(10, 1e-10, 1e-3))
#' volcano.plot(x, p)
#' volcano.plot(x, p, col.mode = 'three')

volcano.plot = function(logfc, pvec, main = NULL, alpha = 0.05,
                        col.mode = 'two', xlim = NULL,
                        cex.main = 1.3, cex.leg = 1.1,
                        cex.axis = 1.3, cex.lab = cex.axis,
                        pch= 16, legend = T,
                        x.legend = max(abs(logfc)) + 0.1) {
  par(xpd = T, mar = c(4.6, 4.6, 3.6, 10))
  if (!legend) par(xpd = T, mar = c(4.6, 4.6, 3.6, 2))
  # check presence of missing values (if so, remove them)
  rem = c(which(is.na(logfc)), which(is.na(pvec)))
  if (length(rem) > 0) {
    logfc = logfc[-rem]
    pvec = pvec[-rem]
  }
  y = -log(pvec, base = 10)
  fdr = p.adjust(pvec, 'BH')
  if (col.mode == 'two') col.points = ifelse(fdr < alpha, 'red', 'blue')
  else if (col.mode == 'three') {
    col.points = rep('black', length(fdr))
    upreg = which(fdr <= alpha & logfc > 0)
    downreg = which(fdr <= alpha & logfc < 0)
    col.points[upreg] = 'red'
    col.points[downreg] = 'blue'
  }
  else stop('col.mode must be either two or three')
  if (is.null(xlim)) {
    maxval = max(abs(range(logfc)))*1.05
    xlim = c(-1, 1)*maxval
  }
  ylim = c(0, max(y)*1.05)
  plot(logfc, y, pch = pch, bty = 'l', main = main,
       col = col.points, xlim = xlim, ylim = ylim,
       cex.main = cex.main, cex.axis = cex.axis, cex.lab = cex.lab,
       xlab = 'logFC', ylab = expression('-log '[10]*' p'))
  y.leg = 0.6*max(y)
  if (col.mode == 'two' & legend) {
    legend(x = x.legend, y = y.leg, paste(c('FDR <', 'FDR >'), alpha), pch = pch,
           col = c('red', 'blue'), bty = 'n', cex = cex.leg)
  }
  if (col.mode == 'three' & legend) {
    legend(x = x.legend, y = y.leg, pch = pch,
           c('up-regulated', 'down-regulated', 'not significant'), 
           col = c('red', 'blue', 'black'), bty = 'n', cex = cex.leg)
  }
  par(xpd = F, mar = c(4.6, 4.6, 4.1, 4.1))
  abline(h=0,v=0, lty = 3)
}
