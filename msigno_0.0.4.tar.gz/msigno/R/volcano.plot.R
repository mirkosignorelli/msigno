#' Creates a volcano plot
#'
#' @export
#' @author Mirko Signorelli
#' @examples
#' set.seed(1)
#' x = rnorm(52)
#' p = c(runif(50), 1e-5, 1e-4)
#' volcano.plot(x, p)

volcano.plot = function(logfc, pvec, main = NULL, alpha = 0.05,
                        pch= 16, x.legend = max(logfc) + 1) {
  par(xpd = T, mar = c(5.1, 4.1, 4.1, 10))
  y = -log(pvec, base = 10)
  fdr = p.adjust(pvec, 'BH')
  plot(logfc, y, pch = pch, bty = 'l', main = main,
       col = ifelse(fdr < alpha, 'red', 'blue'),
       xlab = 'logFC', ylab = expression('-log '[10]*' p'))
  y.leg = 0.5*(min(y) + max(y))
  legend(x = x.legend, y = y.leg, paste(c('FDR <', 'FDR >'), alpha), pch = pch,
         col = c('red', 'blue'), bty = 'n', cex = 1.1)
  par(xpd = F, mar = c(5.1, 4.1, 4.1, 4.1))
  abline(h=0,v=0, lty = 3)
}