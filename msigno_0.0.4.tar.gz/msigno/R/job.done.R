#' Message indicating that your job is finished
#'
#' @export
#' @author Mirko Signorelli
#' @examples
#' job.done()
 
job.done = function(x) {
  system('CMD /C "ECHO Job done. Save the results! && PAUSE"', 
                  invisible=FALSE, wait=FALSE)
}
