#' Round all numeric variables in a data frame
#'
#' @export
#' @author Mirko Signorelli
#' @examples
#' df = data.frame(letters[1:5], runif(5), rpois(5, 3) + rnorm(5))
#' names(df) = c('x', 'y', 'z')
#' dfround(x, digits = 3)
#' dfround(x, digits = c(NA, 3, 2))
 
dfround = function(df, digits) {
  check = do.call(c, lapply(df, is.numeric))
  act = which(check)
  # fix number of digits
  p = ncol(df)
  if (length(digits) == 1) digits = rep(digits, p)
  if (length(digits) != p) {
    mess = paste('data frame is of length ', p,
                 ', while digits is of length ', length(digits), sep = '')
    stop(mess)
  }
    
  if (length(act) > 0) {
    for (i in act) df[ , i] = round(df[ , i], digits[i])
  }
  return(df)
}
