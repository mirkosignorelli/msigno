#' Plot comparing observed pvalues with expected values under the null hypothesis
#'
#' @export
#' @author Mirko Signorelli
#' @examples
#' set.seed(1)
#' x = c(runif(50), 1e-5, 1e-4)
#' pvplot_orig(x, x.inset = -0.3)
 
pvplot_orig = function(x, xlim = NULL, main = NULL, 
                       pch = 16, alpha = 0.05, x.inset = -0.5) {
  x = x[order(x)]
  q = length(x)
  p.exp = (1:q-0.5)/q
  df.pp = data.frame('p' = x, 'p.null' = p.exp)
  fdr = p.adjust(x, method = 'BH')
  col = ifelse(fdr < alpha, 'blue', 'black')
  if (is.null(xlim)) xlim = c(0, range(df.pp$p)[2])
  par(xpd = T, mar = c(5.1, 4.5, 4.1, 9))
  plot(1 - df.pp$p.null, 1 - df.pp$p, xlim = xlim, ylim = xlim,
       main = main, pch = pch, col = col, xlab = expression('Expected 1-p'),
       ylab = expression('Observed 1-p'), cex.lab = 1.5, bty = 'l')
  legend(x = "right", inset=c(x.inset,0), paste(c('FDR <', 'FDR >'), alpha), pch = pch,
         col = c('blue', 'black'), bty = 'n', cex = 1.1)
  par(xpd = F)
  abline(a = 0, b= 1, col = 'red', lwd = 2)
}